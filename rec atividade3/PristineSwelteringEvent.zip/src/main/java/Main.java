

public class Main {
  public static void main(String[] args) {
    String name1 = "Jane";
    String name2 = "Fred";
    System.out.println("unindo os dois nomes" + name1 + name2);
  }

}