
public class Main {
  public static void main(String[] args) {
   int nota = 6;
    int nota = 8
      int medida = (nota1 = nota2) / 2;
    system.out.printnl("a medida das notas é " + medida)
      }

